<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel  ="stylesheet" href = "../css_files/hotel_home_styles.css">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Home</title>
</head>
<body>
<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

        session_start();
?>
    <div class = "menu" text-align = "Center">
        <br><br>
        <ul>
        <li class = "active"><a href="admin_home.html"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="about_us.html"><i class="fa fa-building"></i>About Us</a> </li>
        <li><a href="hotel.php"><i class="fa fa-plus-square"></i>Add New Hotel</a></li>
        <li><a href="viewhoteldetailss.php"><i class="fa fa-eye"></i>View Hotel Details</a> </li>
        <li><a href="#"><i class="fa fa-pencil"></i>Edit Hotel Details</a></li>
        </ul>
        </div>

        <div class="main">

            <p>Welcome to EazyTrip, an online trip planner and guide for travellers. We provide a platform for all new and established hotel companies
                to publish their hotel details on our site for the users to view and book hotels rooms from our site. Please select the suitable options from the menu above to proceed. 
            </p>


        </div>

</body>
</html>