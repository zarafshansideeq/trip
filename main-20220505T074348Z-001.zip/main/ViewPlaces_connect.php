<?php

    include_once "trip_db_connect.php";

  //  $choice = $_POST['choice'];
    $ccode = $_POST['ccode'];

//    if ($choice == 2 || $choice == 3)
  //      $activity = $_POST['activity'];

    
    
        $sql = "select tname, ap, tdesc, apname from touristplaces, activity where ccode = $ccode and touristplaces.ap = activity.apid";
        $result = $conn->query($sql);
        if ($result->num_rows == 0)
        {
            echo "No tourist places found for entered city";
        }
        else
        {   
            echo "<table border = '1'>";
            echo "<tr>";
            echo "<th>Tourist Attraction</th>";
            echo "<th>Activity Preference</th>";
            echo "<th>Description</th>";
            echo "</tr>";
           
            
            while ($row = $result->fetch_assoc())
            {
                echo "<tr>";
                echo "<td>".$row["tname"]."</td>";
                echo "<td>".$row["apname"]."</td>";
                echo "<td>".$row["tdesc"]."</td>";
                echo "</tr>";
            }

            echo "</table>";
        }
    

?>