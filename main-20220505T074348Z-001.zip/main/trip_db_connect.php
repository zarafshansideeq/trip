<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
?>