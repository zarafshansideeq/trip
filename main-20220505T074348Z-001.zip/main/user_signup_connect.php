<?php
    include_once "trip_db_connect.php"; 
    $username = htmlentities($_POST['username']);
    $pass = htmlentities($_POST['password']);
    $name = htmlentities($_POST['name']);
    $mail = htmlentities($_POST['mail']);
    $mobile = htmlentities($_POST['mob']);
    $rpass = htmlentities($_POST['rpassword']);

    $sql = "select max(userid) as id from user";
    $result = $conn->query($sql);
    $row = mysqli_fetch_assoc($result);
    $userid = ++$row["id"]; 
    $sql = "select * from user where username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 0)
    {
        if ($pass == $rpass)
        {
            $sql = "insert into user (userid, username, password, name, mail, contact, roleid) values ('$userid', '$username', '$pass', '$name', '$mail', '$mobile', 2)";
            $conn->query($sql);
            header('location: ../index.html');
        }
    }
    else
    {
        echo "Username already exists";

    }
    $conn->close();

?>