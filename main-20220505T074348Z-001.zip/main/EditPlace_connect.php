<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Place</title>
</head>
<body>
    
<?php

$ccode = $_POST['city'];
$tpname = htmlentities($_POST['tp']);
//echo $tpname;
session_start();
$_SESSION['ccode'] = $ccode;
$_SESSION['tpname'] = $tpname;
/*$sql = "select * from touristplaces where ccode = $ccode and tname = '$tpname'";
$rows = $conn->query($sql);
$row = $result->fetch_assoc();*/
?>

<form action = "EditPlace_connect_connect.php" method = 'POST'>

<label for="city">City:</label><br>
  <select name="city" id="city">
  <option>--select--</option>
      <?php
        $sql = "select * from city";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {   
            $ccode = $row["ccode"];
            $city = $row["cname"];
            echo "<option value = '$ccode'>$city</option>";
        }
      ?>
</select>

  
  <br><br>

  
  <label for="tname">Tourist Place Name</label><br>
  <input type="text" id="tname" name="tname">
<br><br>


  <label for="ap">Activity Preference</label><br>
  <select name="ap" id="ap">
  <option>--select--</option>
  <option value="1">Adventure</option>
  <option value="2">Beach</option>
  <option value="3">Cultural</option>
  <option value="4">Historic</option>
  <option value="5">Relaxing</option>
  <option value="6">Nature & WIldlife</option>
  <option value="7">Parks and Gardens</option>
  <option value="8">Romantic</option>
  <option value="9">Shopping</option>
  <option value="10">Trekking</option>
  <option value="11">Museum</option>
  <option value="12">Zoo</option>
</select>


<br><br>
<label for="tdesc">Description:</label>
<br>
<textarea id="tdesc" name="tdesc"></textarea><br><br>
  


  <button class="btn">Add to Database</button>

</form>

</body>
</html>