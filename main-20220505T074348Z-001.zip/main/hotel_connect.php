<?php

    include_once "trip_db_connect.php";
    session_start();
    //Variable Declarations
    $userid = $_SESSION['userid'];

    $name = htmlentities($_POST['hname']);
    $hccode = $_POST['city'];
    
    $room1 = htmlentities($_POST['room1']);
    $room2 = htmlentities($_POST['room2']);
    $room3 = htmlentities($_POST['room3']);
    $room4 = htmlentities($_POST['room4']);
    
    $cost1 = htmlentities($_POST['cost1']);
    $cost2 = htmlentities($_POST['cost2']);
    $cost3 = htmlentities($_POST['cost3']);
    $cost4 = htmlentities($_POST['cost4']);

    $desc = htmlentities($_POST['hdesc']);
    $address = htmlentities($_POST['address']);
    $contact = htmlentities($_POST['cont']);

    $sql = "select max(hid) as id from hotel";
    $result = $conn->query($sql);
    if ($result->num_rows == 0)
    {
        $hid = 1;
    }
    else
    {
        $row = mysqli_fetch_assoc($result);
        $hid = ++$row["id"]; 
    }

    $sql = "insert into hotel (hid, user_id, hname, hccode, hdesc, address, contact) values ('$hid', '$userid', '$name', '$hccode', '$desc', '$address', '$contact')";
    $conn->query($sql);
    echo $sql;

    $sql = "select max(roomid) as id from hotelroomdetails";
    $result = $conn->query($sql);
    if ($result->num_rows == 0)
    {
        $roomid = 1;
    }
    else
    {
        $row = mysqli_fetch_assoc($result);
        $roomid = ++$row["id"]; 
    }

    $sql = "insert into hotelroomdetails (roomid, hotelid, roomtypeid, rnumber, rcost) values ('$roomid', '$hid', 1, '$room1', '$cost1')";
    $conn->query($sql);
    ++$roomid;

    $sql = "insert into hotelroomdetails (roomid, hotelid, roomtypeid, rnumber, rcost) values ('$roomid', '$hid', 2, '$room2', '$cost2')";
    echo $sql;
    $conn->query($sql);
    ++$roomid;

    $sql = "insert into hotelroomdetails (roomid, hotelid, roomtypeid, rnumber, rcost) values ('$roomid', '$hid', 3, '$room3', '$cost3')";
    $conn->query($sql);
    ++$roomid;

    $sql = "insert into hotelroomdetails (roomid, hotelid, roomtypeid, rnumber, rcost) values ('$roomid', '$hid', 4, '$room4', '$cost4')";
    $conn->query($sql);


$conn->close();
    
//header ('location: hotel.php');
?>