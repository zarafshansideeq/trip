<html>
<head>
    <link rel = "stylesheet" href = "../css_files/plan_styles.css">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        
        .main select 
        {
            width: 140px;
            font-size: 20px;
        }
        .main table tr
        {
            margin-top: 5px;
        }
        a
        {
            text-decoration: none;
        }

        .main
        {
            top: 57%;
        }

        .menu ul li
        {
            margin: 20px;
            padding: 20px;
            width: 210px;
        }
        .btn
        {
            cursor: pointer;
            background-color: #4CAF50;
        }
        </style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <script>
        $(function(){
        var dtToday = new Date();
    
        var month = dtToday.getMonth() + 1;
        var day = dtToday.getDate();
        var year = dtToday.getFullYear();
        if(month < 10)
            month = '0' + month.toString();
        if(day < 10)
            day = '0' + day.toString();
    
        var minDate= year + '-' + month + '-' + day;
    
        $('#start').attr('min', minDate);
        $('#end').attr('min', minDate);
        });
    </script>

<script>
    function validate()
    {
        var s1 = document.getElementById('source').value;
        var s2 = document.getElementById('dest').value;
        var a = document.getElementsByName('activity[]');
        var start = document.getElementById('start').value;
        var end = document.getElementById('end').value;

        if (s1 == "--select--")
        {
            alert("Please select source");
            return false;
        }
        
        else if (s2 == "--select--")
        {
            alert("Please select destination");
            return false;
        }
        
        else if (s1 == s2)
        {
            alert("Error: Source and Destination cannot be same");
            return false;
        }

        else if (start > end)
        {
            alert("Error: End Date should come after Start date")
            return false;
        }

        else
        {
            for (var i=0; i<a.length; i++)
            {
                if (a[i].checked == true)
                    break;
            }
            if (i == a.length)
            {
                alert("Please select atleast one activity preference");
                return false;
            }
        }
        
        return true;
    }
</script>
</head>
<?php
        include_once "trip_db_connect.php";         // Database Connection
        session_start();
?>
<body>

<div class = "menu" text-align = "Center">
        <br><br>
        <ul>
        <li class = "active"><a href="plan.php"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="about_us.html"><i class="fa fa-building"></i>About Us</a></li>
        <li><a href="#"><i class="fa fa-h-square"></i>Search Hotels</a></li>
        <li><a href="mybookings.php"><i class="fa fa-book"></i>View Bookings</a></li>
        <li><a href="Contact us.html"><i class="fa fa-phone"></i>Contact Us</a></li>
        <li><a href="Contact us.html"><i class="fa fa-sign-out"></i>Log Out</a></li>
        </ul>
</div>



<div class="main">
<form action = "plan_connect.php" onsubmit = "return validate()" method = "POST" name = "forms";>
    Welcome to EazyTrip, your personal Online Trip Guide.<br>
    Start planning your trip here by filling the below details:<br><br>
    
	<label for="source">Source</label>
	<select name="src" id="source">
    <option>--select--</option>
    <?php
        $sql = "select * from city";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {   
            $ccode = $row["ccode"];
            $city = $row["cname"];
            echo "<option value = '$ccode'>$city</option>";
        }
    ?>
</select>
    
    <label for="dest" style="margin-left:30px;">Destination</label>
    <select name="dest" id="dest">
    <option>--select--</option>
    <?php
        $sql = "select * from city";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {   
            $ccode = $row["ccode"];
            $city = $row["cname"];
            echo "<option value = '$ccode'>$city</option>";
        }
    ?>
</select>
    

    <br><br>    
    <label for="start">Start Date</label>
	<input type="date" id="start" name="start" value = "<?php echo date(Y-m-d) ?>" style="margin-right: 30px;" required> 
    
    <label for="end">End Date</label>
	<input type="date" id="end" name="end" value = "<?php echo date(Y-m-d) ?>" required><br>
    <?php 
        $conn->close();
    ?>
    
    <br>
    Activity Preferences:<br>
    <table style="font-size: 20px;">
        <tr>
        <td><input type="checkbox" id="adventure" name="activity[]" value = "1">
        <label for="adventure">Adventure</label></td>
    
        <td><input type="checkbox" id="beaches" name="activity[]" value = "2">
        <label for="beaches">Beaches</label></td>
    
        <td><input type="checkbox" id="cultural" name="activity[]" value = "3">
        <label for="cultural">Cultural</label></td>	
    
        <td><input type="checkbox" id="hp" name="activity[]" value = "4">
        <label for="hp">Historic Places</label></td>
        </tr>
    
        <tr>
        <td><input type="checkbox" id="relaxing" name="activity[]" value = "5">
        <label for="relaxing">Relaxing</label></td>
    
        <td><input type="checkbox" id="nature" name="activity[]" value = "6">
        <label for="nature">Nature and Wildlife</label></td>
    
        <td><input type="checkbox" id="png" name="activity[]" value = "7">
        <label for="png">Parks and Gardens</label></td>	
        
        <td><input type="checkbox" id="romantic" name="activity[]" value = "8">
        <label for="romantic">Romantic</label></td>
        </tr>	
        
        <tr>
        <td><input type="checkbox" id="shopping" name="activity[]" value = "9">
        <label for="shopping">Shopping</label></td>
    
        <td><input type="checkbox" id="trekking" name="activity[]" value = "10">
        <label for="trekking">Trekking</label></td>
    
        <td><input type="checkbox" id="museums" name="activity[]" value = "11">
        <label for="museums">Museums</label></td>	
    
        <td><input type="checkbox" id="zoo" name="activity[]" value = "12">
        <label for="zoo">Zoo Visit</label></td>
        </tr></table>
    <br>
    <button class="btn">Start Planning</button>
    </form>
    </div>


    
</div>
    </body>
    </html>