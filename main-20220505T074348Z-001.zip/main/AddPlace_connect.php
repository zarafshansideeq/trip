<?php

    include_once "trip_db_connect.php";  //Connect
 //   $tid = htmlentities($_POST['tid'], ENT_QUOTES);
    $ccode = htmlentities($_POST['city'], ENT_QUOTES);
    $tname = htmlentities($_POST['tname'], ENT_QUOTES);
    $ap = $_POST['ap'];
    $tdesc = htmlentities($_POST['tdesc'], ENT_QUOTES);
    
    $sql = "select max(tid) as id from touristplaces";
    $result = $conn->query($sql);
    if ($result->num_rows == 0)
    {
        $tid = 1;
    }
    else
    {
        $row = mysqli_fetch_assoc($result);
        $tid = ++$row["id"]; 
    }

    $sql = "insert into touristplaces (tid, ccode, tname, ap, tdesc) values ($tid, '$ccode', '$tname', '$ap', '$tdesc')";
    //echo $sql;
    if ($conn->query($sql))
        {
    //        echo "New record inserted successfully";
                header('location: AddPlace.php');
        }
        else
        {
            echo "Error".$sql."<br>".$conn->error;
        }
        
        $conn -> close();
       //header('location: AddPlace.php')
?>































/*
if(!empty($city))
{
    if(!empty())
    {
        $host = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //COnnection:
        $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);
        if ((mysqli_connect_error()))
        {
            die('Connect Error ('.mysqli_connect_errno().')'.mysqli_connect_error());
        }
        else
        {
            $sql = select ccode from city where cname = $city
        }
    }
    else
    {
        echo "Please enter tourist place name";
        die();
    }
}
else{
    echo "Please enter city name";
    die();
} */
