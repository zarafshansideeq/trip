<?php

    include_once "trip_db_connect.php";

    session_start();
    $hid = $_SESSION['hid'];
    $userid = $_SESSION['userid'];

    $roomtypeid = $_POST['roomtype'];
    $num = htmlentities($_POST['num']);
    $indate = date('Y-m-d', strtotime($_REQUEST['indate']));
    $outdate = date('Y-m-d', strtotime($_REQUEST['outdate']));

    $in = strtotime($indate);
    $out = strtotime($outdate);
    $days = ceil(abs($out - $in) / 86400);

    $i=0;
    $date = $indate;

    $sql = "select roomid, rnumber from hotelroomdetails where hotelid = $hid and roomtypeid = $roomtypeid";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $roomid = $row["roomid"];
    echo $roomid;
    $maxnum = $row["rnumber"];
    $whichdates = array();
    $j=0;

    for ($i=0; $i<$days; $i++)
    {
        $sql = "select sum(number) as occ from booking where roomid=$roomid and indate<='$date' and outdate>'$date'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        if ($result->num_rows > 0)
        {
            $occ = $row["occ"] + $num;
            if ($occ >= $maxnum)
            {
                $whichdates[$j] = $date;
                //echo count($whichdates);
                $j++;
            }
            else
            {
                //Proceed
            }
        }
        else
        {
            //Proceed
        }
        $date++;
    }

    

    if ($j>0)
    {
        echo "<script>
            alert('Requested Rooms Not Available on Given Dates');
        </script>";
        //echo "<br>Rooms unavailable on ";
        //for ($i=0; $i<$j; $i++)
        //{
          //  echo $whichdates[$i].", ";
        //}
    }
    else
    {
        $sql = "select max(bookingid) as id from booking";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $id = ++$row["id"];

        $sql = "select rcost from hotelroomdetails where roomid = $roomid";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();        
        $cost = $row["rcost"];
        $amt = $cost * $num * $days;

        $sql = "CALL add_booking($id, $userid, $roomid, '$indate', '$outdate', $num, $amt)";
        echo $sql;
        if ($conn->query($sql))
        {
            echo "<script>
                alert ('Booking Addded Successfully');
            </script>";
        }

        /*$sql = "insert into hotelbooking (bookingid, userid, hotelid, roomtype, indate, outdate, number, amount) values ($id, $userid, $hid, $roomtypeid, '$indate', '$outdate', $num, $amt)";
        if ($conn->query($sql))
        {
            echo "<script>
                alert ('Booking Addded Successfully');
            </script>";
        }*/

        // SET @p0='13'; SET @p1='1'; SET @p2='2'; SET @p3='2'; SET @p4='2021-05-21'; SET @p5='2021-05-22'; SET @p6='1'; SET @p7='1000'; CALL `add_booking`(@p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7);

        

    }

    $conn->close();


?>