<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "../css_files/AddCity_styles.css">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        
.menu
{
	text-align: center;
}

.menu ul
{
	display: inline-flex; 
	list-style: none;
	color: #fff
}

.menu ul li
{
	width: 175px;
	margin: 15px;
	padding: 15px;
}

.menu ul li a
{
	color: rgb(255,255,255);
	font-size: 25px; 
}

.active, .menu ul li:hover
{
	background: rgb(0,128,0); 
	border-radius: 4px;
}

.menu .fa
{
	margin-right: 8px;
}

.sub_menu
{
	display: none;
}

.menu ul li:hover .sub_menu
{
	display: block;
	position: absolute;
	background: rgb(0,100,0);
	margin-top: 10 px;
	margin-left: -10 px;
}

.menu ul li:hover .sub_menu ul
{
	display: block;
	padding: 10px;
	border-bottom: 1px dotted #FFF;
	background: tansparent;
	border-radius: 0;
}

        .main label
        {
            font-size: 20px;
            color: rgb(255,255,255);
        }
        .main input[type=text]
        {
            width: 200px;
            height: 30px;
        }

        .main select
        {
            width: 200px;
            height: 30px;
            font-size: 20px;
        }
        .main .btn
        {
            height: 35px;
            width: 160px;
        }

.main select
{
    width: 175px;
    font-size: 20px;
}
.btn
{
    font-size: 17.5px;
    width: 100px;
    height: 40px;
}
    </style>
    <title>Search Places</title>
</head>
<body>

<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
?>
    
    <div class = "menu" text-align = "Center">
        <br><br>
        <ul>
        <li class = "active"><a href="admin_home.html"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="#"><i class="fa fa-globe"></i>City Details</a>
        <div class="sub_menu">
            <ul>
            <li><a href="AddCity.html">Add New City</a></li>
            <li><a href="EditCity.php">Edit City Name</a></li>
            <li><a href="viewcities.php">View Cities</a></li>
            </ul>
        </div> </li>
        <li><a href="#"><i class="fa fa-map-marker"></i>Tourist Attractions</a>
        <div class="sub_menu">
            <ul>
            <li><a href="AddPlace.php">Add Tourist Place</a></li>
            <li><a href="ViewPlaces.php">View Tourist Places</a></li>
            </ul>
        </div></li>
        <li><a href="viewbookings.php"><i class="fa fa-bookmark"></i>View Bookings</a>
        <li><a href="#"><i class="fa fa-star"></i>Rating and Reviews</a></li>
        <li><a href="#"><i class="fa fa-sign-out"></i>Logout</a></li>
        </ul>
        </div>


  
    <div class="main">
    <form action = "ViewPlaces_connect.php" method = "POST">

        <label for="ccode">Select City</label>
	    <select name="ccode" id="ccode">
        <option>--select--</option>
        <?php
            $sql = "select * from city";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc())
            {   
                $ccode = $row["ccode"];
                $city = $row["cname"];
                echo "<option value = '$ccode'>$city</option>";
            }
        ?>
        </select>

        <br><br>

        <button class="btn">Search</button>

    </form> 
</div>
<?php
$conn->close();
?>
</body>
</html>