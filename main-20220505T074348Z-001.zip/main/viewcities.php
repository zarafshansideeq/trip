<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel  ="stylesheet" href = "../css_files/view_cities_styles.css">
    <title>View Cities</title>
</head>
<body>
    
<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
echo "<body>";
    echo "<div class = 'main'>";
    echo "<table border = '1' style='margin-left: auto; margin-right: auto; border-color; white;'>";
    echo "<tr>";
    echo "<th>City Code</th>";
    echo "<th>City Name</th>";    
    echo "</th>";
    $sql = "select * from city";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {
            echo "<tr>";
            echo "<td>".$row["ccode"]."</td>";   
            echo "<td>".$row["cname"]."</td>";  
            echo "</tr>";
        }
    echo "</table>";
    echo "</div>";
echo "</body>";
$conn->close();
?>
</body>
</html>