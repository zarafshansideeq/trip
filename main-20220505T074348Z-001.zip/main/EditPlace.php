<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Tourist Place</title>
    <link rel = "stylesheet" href = "../css_files/AddCity_styles.css">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
            .main select
            {
                width: 170px;
                height: 25px;
                font-size: 20px;
            }

            .main input
            {
                width: 500px;
            }
            .btn
            {
                
            }
        </style>
</head>
<body>
    
<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
?>

    <div class="main">

        <form action = "EditPlace_connect.php" method = "POST">
<br>
        Enter Following Details:<br><br>

        <label for="city">City:</label><br>
  <select name="city" id="city">
  <option>--select--</option>
      <?php
        $sql = "select * from city";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {   
            $ccode = $row["ccode"];
            $city = $row["cname"];
            echo "<option value = '$ccode'>$city</option>";
        }
      ?>
</select><br><br>

        <label for = "touristplace">Enter Tourist Place</label><br>
        <input type = "text" id = "touristplace" name = "tp">
        <br><br>
        <button class="btn">Search</button>
 
        </form>
    </div>

</body>
</html>