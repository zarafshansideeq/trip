<!DOCTYPE html>
<html>
<head>
	<title>Add Places</title>
	<link rel="stylesheet" href="../css_files/AddPlace_styles.css">
	<style>

.menu
{
	text-align: center;
}

.menu ul
{
	display: inline-flex; 
	list-style: none;
	color: #fff
}

.menu ul li
{
	width: 175px;
	margin: 15px;
	padding: 15px;
}

.menu ul li a
{
	color: rgb(255,255,255);
	font-size: 25px; 
}

.active, .menu ul li:hover
{
	background: rgb(0,128,0); 
	border-radius: 4px;
}

.menu .fa
{
	margin-right: 8px;
}

.sub_menu
{
	display: none;
}

.menu ul li:hover .sub_menu
{
	display: block;
	position: absolute;
	background: rgb(0,100,0);
	margin-top: 10 px;
	margin-left: -10 px;
}

.menu ul li:hover .sub_menu ul
{
	display: block;
	padding: 10px;
	border-bottom: 1px dotted #FFF;
	background: tansparent;
	border-radius: 0;
}

    .main
    {
      top: 50%;
    }

    .main input
    {
      font-size: 15px;
    }
    </style>
<body>
	<?php
    include_once "trip_db_connect.php";
?>
    
<div class = "menu" text-align = "Center">
        <br><br>
        <ul>
        <li class = "active"><a href="admin_home.html"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="#"><i class="fa fa-globe"></i>City Details</a>
        <div class="sub_menu">
            <ul>
            <li><a href="AddCity.html">Add New City</a></li>
            <li><a href="EditCity.php">Edit City Name</a></li>
            <li><a href="viewcities.php">View Cities</a></li>
            </ul>
        </div> </li>
        <li><a href="#"><i class="fa fa-map-marker"></i>Tourist Attractions</a>
        <div class="sub_menu">
            <ul>
            <li><a href="AddPlace.php">Add Tourist Place</a></li>
            <li><a href="ViewPlaces.php">View Tourist Places</a></li>
            </ul>
        </div></li>
        <li><a href="viewbookings.php"><i class="fa fa-bookmark"></i>View Bookings</a>
        <li><a href="#"><i class="fa fa-star"></i>Rating and Reviews</a></li>
        <li><a href="#"><i class="fa fa-sign-out"></i>Logout</a></li>
        </ul>
        </div>
<div class="main">
<form method = "POST" action="AddPlace_connect.php">
 

<h2><u>Add Tourist Place</u></h2>

  <label for="city">City:</label><br>
  <select name="city" id="city" required>
  <option>--select--</option>
      <?php
        $sql = "select * from city";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {   
            $ccode = $row["ccode"];
            $city = $row["cname"];
            echo "<option value = '$ccode'>$city</option>";
        }

        $conn->close();
      ?>
</select>

  
  <br><br>

  
  <label for="tname">Tourist Place Name</label><br>
  <input type="text" id="tname" name="tname" required>
<br><br>


  <label for="ap">Activity Preference</label><br>
  <select name="ap" id="ap">
  <option>--select--</option>
  <option value="1">Adventure</option>
  <option value="2">Beach</option>
  <option value="3">Cultural</option>
  <option value="4">Historic</option>
  <option value="5">Relaxing</option>
  <option value="6">Nature & WIldlife</option>
  <option value="7">Parks and Gardens</option>
  <option value="8">Romantic</option>
  <option value="9">Shopping</option>
  <option value="10">Trekking</option>
  <option value="11">Museum</option>
  <option value="12">Zoo</option>
</select>


<br><br>
<label for="tdesc">Description:</label>
<br>
<textarea id="tdesc" name="tdesc"></textarea><br><br>
  


  <button class="btn">Add to Database</button>
</form>
</div>
</body>
</html>