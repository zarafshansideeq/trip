<?php

    include_once "trip_db_connect.php";

    $ccode = $_POST['name'];
    $cname = htmlentities($_POST['cname']);

    $sql = "update city set cname = '$cname' where ccode = '$ccode'";
    $result = $conn->query($sql);
    $conn->close();
    header ('location: EditCity.php');

?>