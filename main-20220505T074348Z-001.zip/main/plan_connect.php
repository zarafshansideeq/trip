<?php

    include_once "trip_db_connect.php";

    echo "<head>
    <link rel = 'stylesheet' href = '../css_files/plan_connect_styles.css'>
    <link rel = 'stylesheet' href = 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <style>
    .image
    {
        text-align: center;
    }
    body
    {
        background-color: aqua;
        
    }
    a:unvisited
    {
        color: black;
        text-decoration: none;
    }
    a:visited
    {
        color: black;
        text-decoration: none;
    }
    a:hover
    {
        color: green;
    }
    .tbl
    {
        margin-left: auto;
        margin-right: auto;
        background: rgba(256,256,256,1);
    }

    button
    {
        height: 40px;
        font-size: 18px;
    }

    a
    {
        text-decoration: none;
    }

    .tbl tr td
    {
        vertical-align: top;
    }
    
    </style>
    </head>";


    $src = $_POST['src'];
    $dest = $_POST['dest'];
    $start = date('Y-m-d', strtotime($_REQUEST['start']));
    $end = date('Y-m-d', strtotime($_REQUEST['end']));
    $s = strtotime($start);
    $e = strtotime($end);
    $days = ceil(abs($e - $s) / 86400);
    ++$days;
    $activity = $_POST['activity'];
    $num = count($activity);
    $date = $start;
    session_start();

    
    
    $sql = "select cname from city where ccode = '$dest'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $destination = $row["cname"];
    $_SESSION['ccode'] = $dest;

    echo "<br>";
    echo "<h1>".$days." Days Trip to ".$destination."</h1>";

    echo "<div class = 'hyperlink'>";
    echo "<button><a href = 'searchhotels.php'>Click Here to Search Hotels</a></button>";
    echo "</div>";
    //echo "<br><br>";

    //echo "<div class = 'hyperlink'>";
    //echo "<a href = '#plan'>Scroll Down For Further Details <i class='fa fa-angle-double-down'></i></a>";
    //echo "<//div>";
    //echo "<br><br>";

    //echo "<div class = 'image'>";
    //echo "<img src = '../images/travel_image.jpg' alt = 'Image Could Not Load' height = '500' width = '1375'>";
    //echo "</div>";
    
    //echo "<br><br>";

    

    echo "<br><h1 id = 'plan'>Find Your Daily Trip Plan Below:</h1>";
    
    if ($days%2 == 0)
    {
        $nplaces = 7*$days/2;
    }
    else 
    {
        $nplaces = 7*(($days-1)/2) + 4;
    }
    


    $sum = 0;

    for ($i=0; $i<$num; $i++)
    {
        $sql = "select count(*) as tot from touristplaces where ccode = '$dest' and ap = $activity[$i]";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $tot = $row["tot"];
        $sum += $tot;
    }


    $count = 0;
    $sql = "select * from touristplaces where ccode = $dest";
    //$sql = "call showplaces($dest)";
    $result = $conn->query($sql);
    echo "<table class = 'tbl' border='1' style = 'width: 100%;'>";
    while($row = $result->fetch_assoc())
    {
        if (in_array($row["ap"], $activity))
        {
            if ($count++ != $nplaces)
            {
                if ($count%7 == 1 || $count%7 == 5)
                {
                    $date++;
                    echo "<tr>";
                    echo "<td><h2>".$date."</h2></td>";
                    echo "<td><h3><u>".$row["tname"]."</u></h3>";
                    echo $row["tdesc"]."</td>";
                }
                else
                {
                    //echo "<br>";
                    echo "<td><h3><u>".$row["tname"]."</u></h3>";
                    echo $row["tdesc"]."</td>";
                    //echo "</tr>";
                    if ($count%7 == 0 || $count%7 == 4)
                    {
                        echo "</tr>";
                    }
                }
            }
            else
            {
                break;
            }
        }
    }

    if ($count<$nplaces)
    {
        //$sql = "call showplaces($dest)";
        $sql = "select * from touristplaces where ccode = $dest";
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc())
        {
            if (!in_array($row["ap"], $activity))
            {
                if ($count++ != $nplaces)
                    {
                        if ($count%7 == 1 || $count%7 == 5)
                    {
                        $date++;
                        echo "<tr>";
                        echo "<td><h2>".$date."</h2></td>";
                        echo "<td><h3><u>".$row["tname"]."</u></h3>";
                        echo $row["tdesc"]."</td>";
                    }
                    else
                    {
                        //echo "<br>";
                        echo "<td><h3><u>".$row["tname"]."</u></h3>";
                        echo $row["tdesc"]."</td>";
                        if ($count%7 == 0 || $count%7 == 4)
                        {
                            echo "</tr>";
                        }
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }
    echo "</table>";
    $conn->close();

?>

