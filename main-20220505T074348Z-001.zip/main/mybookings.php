<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel  ="stylesheet" href = "../css_files/mybookings_connect.css">
    <title>My Bookings</title>
</head>
<body>
    
<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

    session_start();
    $userid = $_SESSION['userid'];

    echo "<body>";
    echo "<div class = 'main'>";
    echo "<h2>My Bookings</h2>";
    echo "<table border = '1' style='margin-left: auto; margin-right: auto; border-color; white;'>";
    echo "<tr>";
    echo "<th>Booking ID</th>";
    //echo "<th>Customer</th>";    
    echo "<th>Hotel</th>";    
    echo "<th>Room Type</th>";    
    echo "<th>Number of Rooms</th>";    
    echo "<th>Check-in Date</th>";    
    echo "<th>Check-out Date</th>";    
    echo "<th>Total Bill</th>";    
    echo "</th>";
    $sql = "select bookingid, name, hname, roomtypename, number, indate, outdate, amount from hotelbooking, hotel, user, roomtypes where hotelbooking.userid = $userid and hotelbooking.userid = user.userid and hotelbooking.hotelid = hotel.hid and hotelbooking.roomtype = roomtypes.roomtypeid order by bookingid";
        $result = $conn->query($sql);
      //  echo $sql;
        while($row = $result->fetch_assoc())
        {
            echo "<tr>";
            echo "<td>".$row["bookingid"]."</td>";   
          //  echo "<td>".$row["name"]."</td>"; 
            echo "<td>".$row["hname"]."</td>";   
            echo "<td>".$row["roomtypename"]."</td>"; 
            echo "<td>".$row["number"]."</td>";   
            echo "<td>".$row["indate"]."</td>"; 
            echo "<td>".$row["outdate"]."</td>";   
            echo "<td>".$row["amount"]."</td>";  
            echo "</tr>";
        }
    echo "</table>";
    echo "</div>";
echo "</body>";
?>
</body>
</html>