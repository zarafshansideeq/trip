<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Details</title>
    <link rel = "stylesheet" href = "../css_files/viewhoteldetailss_styles.css">
</head>
<body>
<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

        session_start();
        $userid = $_SESSION['userid'];
      //  echo $userid;
        $sql = "select * from hotel where user_id = $userid";
        $result = $conn->query($sql);

        $sql1 = "select * from hotelroomdetails where user_id = $userid"
        
        while ($row = $result->fetch_assoc())        
        {
            echo "<div class = 'main'>";
            echo "<h1>".$row["hname"]."</h1>";
            echo "<p>".$row["hdesc"]."</p><br>";
            echo "<h2>Room Types</h2>";
            
            echo "</div>";
        }
?>


</body>
</html>