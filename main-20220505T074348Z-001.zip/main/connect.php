<?php
        include_once "trip_db_connect.php";                                              // Connect to Database
        $username = htmlentities($_POST['username']);          
        $pass = htmlentities($_POST['password']);

        session_start();                                                                // Start of Session
        
        $sql = "select password, roleid from user where username = '$username'";        // SQL Query
        $result = $conn->query($sql);                                                           
        $row = mysqli_fetch_assoc($result);

        if ($result->num_rows > 0)                                                      // If username exists    
        {
            if ($row["password"] == $pass)                                              // Verifying Password
            {

                $_SESSION['username'] = $username;                                        
                $sql1 = "select userid from user where username = '$username'";
                $result1 = $conn->query($sql1);
                $row1 = $result1->fetch_assoc();
                $_SESSION['userid'] = $row1["userid"];

                if ($row["roleid"] == 1)
                {
                    header('location: admin_home.html');    
                }
                elseif ($row["roleid"] == 2)
                {
                    header('location: plan.php');
                }
                elseif ($row["roleid"] == 3)
                {
                    header('location: hotel_home.php');
                }
            }
            else
            {
                echo "<script>
                alert ('Incorrect Username or Password');


                </script>";
                //header('location: ../index.html?message=Incorrect Username or Password');
            }
        }
        else
        {
            echo "<script>
            alert ('Username does not exist');
            </script>";            
        }

        //header('location: ../index.html');

        

        $conn->close();
        
        
?>