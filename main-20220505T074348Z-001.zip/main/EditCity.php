<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "../css_files/EditCity_styles.css">
    <title>Edit City</title>
    <style>
        
        .menu
{
	text-align: center;
}

.menu ul
{
	display: inline-flex; 
	list-style: none;
	color: #fff
}

.menu ul li
{
	width: 175px;
	margin: 15px;
	padding: 15px;
}

.menu ul li a
{
	color: rgb(255,255,255);
	font-size: 25px; 
}

.active, .menu ul li:hover
{
	background: rgb(0,128,0); 
	border-radius: 4px;
}

.menu .fa
{
	margin-right: 8px;
}

.sub_menu
{
	display: none;
}

.menu ul li:hover .sub_menu
{
	display: block;
	position: absolute;
	background: rgb(0,100,0);
	margin-top: 10 px;
	margin-left: -10 px;
}

.menu ul li:hover .sub_menu ul
{
	display: block;
	padding: 10px;
	border-bottom: 1px dotted #FFF;
	background: tansparent;
	border-radius: 0;
}

        .main label
        {
            font-size: 20px;
        }
        .main input[type=text]
        {
            width: 200px;
            height: 30px;
        }

        .main select
        {
            width: 200px;
            height: 30px;
            font-size: 20px;
        }
        .main .btn
        {
            height: 35px;
            width: 160px;
        }
        </style>

<script>
function validate()
{
    var city = document.getElementById('cityname').value;
    if (city == "--select--")
        {
            alert("Please select city");
            return false;
        }
    return true;
}
</script>

</head>
<body>
    
<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);
?>
    
    <div class = "menu" text-align = "Center">
        <br><br>
        <ul>
        <li class = "active"><a href="admin_home.html"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="#"><i class="fa fa-globe"></i>City Details</a>
        <div class="sub_menu">
            <ul>
            <li><a href="AddCity.html">Add New City</a></li>
            <li><a href="EditCity.php">Edit City Name</a></li>
            <li><a href="viewcities.php">View Cities</a></li>
            </ul>
        </div> </li>
        <li><a href="#"><i class="fa fa-map-marker"></i>Tourist Attractions</a>
        <div class="sub_menu">
            <ul>
            <li><a href="AddPlace.php">Add Tourist Place</a></li>
            <li><a href="ViewPlaces.php">View Tourist Places</a></li>
            </ul>
        </div></li>
        <li><a href="viewbookings.php"><i class="fa fa-bookmark"></i>View Bookings</a>
        <li><a href="#"><i class="fa fa-star"></i>Rating and Reviews</a></li>
        <li><a href="#"><i class="fa fa-sign-out"></i>Logout</a></li>
        </ul>
        </div>


    <div class="main">

        <h3>Edit City Name</h3>
        <form action = "EditCity_connect.php" onsubmit = "return validate()" method = "POST">

        <label for="cityname">Select City</label>
	    <select name="name" id="cityname">
        <option>--select--</option>
        <?php
            $sql = "select * from city";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc())
            {   
                $ccode = $row["ccode"];
                $city = $row["cname"];
                echo "<option value = '$ccode'>$city</option>";
            }
        ?>
    </select>
<br><br>
        <label for = "cname">New Name</label>
        <input type = "text" id = "cname" name = "cname" required> 
<br><br>
        <button class="btn" style="width: 170px;">Edit</button>

        </form>

    </div>
<?php
    $conn->close();
?>
</body>
</html>