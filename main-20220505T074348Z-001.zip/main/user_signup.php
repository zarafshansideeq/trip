<html>
    <head>
        <link rel="stylesheet" href="../css_files/user_styles.css">

        <script>
            function validate()
            {
                var text = document.getElementById('mob').value;
                var regx = /^[7-9]\d{9}$/;
            
                if (!regx.test(text))
                {
                    alert ("Please enter valid mobile number");
                    return false;
                }
            }
        </script>
    
    </head>
    <body>
        

        <div class="main">
            <h1>SignUp</h1>
            <form action = "user_signup_connect.php" method = "POST" onsubmit = "return validate()">
                
                <label for="username">Username: </label>
                <input type="text" id="username" placeholder="" name="username"d required><br><br>
                
                <label for="name">Name: </label>
                <input type="text" id="name" placeholder="" name="name"required >
                <br><br>
                
                <label for="mail">Mail ID: </label>
                <input type="email" id="mail" placeholder="" name="mail" required><br><br>
                
                <label for="mob">Mobile Number: </label>
                <input type="text" id="mob" placeholder="" name="mob" required><br><br>
                
                <label for="password">Password: </label>
                <input type="password"id="password" placeholder="Enter Password" name="password" required><br><br>
                
                <label for="password">Confirm Password: </label>
                <input type="password" id="password" placeholder="Re-Enter Password" name="rpassword" required><br><br>
                
                <input type="checkbox" id="t&c" required>
                <label for="t&c">I have Read and Agreed To the <a href="#">Terms of Use</a> and <a href="#">Privacy Policy</a></label><br><br>
             
                <button type="submit">Sign Up</button><br>
            </form>
            <br>
        </div>
    </body>
</html>
