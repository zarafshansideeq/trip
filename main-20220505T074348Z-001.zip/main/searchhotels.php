<?php

    include_once "trip_db_connect.php";
    session_start();

    echo "<head>
        <style>

        .main
        {
            width: 80%;  
	        background: rgba(0,0,0,.8);
	        color: white;
	        text-align: center;
	        padding: 50px;
	        position: absolute;
	        top: 50%;
	        left: 50%;
	        transform: translate(-50%,-50%);
        }

        .main table
        {
            color: white;
            font-size: 17.5px;
            text-align: center;
        }

        .main th
        {
            font-size: 20px;
        }

        .main table td
        {
            width: 500px;
        }

        .main a
        {
            text-decoration: none;
        }

        .main a:visited
        {
            color: black;
        }

        .main a:hover
        {
            color: green;
        }

        .main button
        {
            height: 50px;
            width: 110px;
            font-size: 20px;
        }
        .tbl
        {
            margin-left: auto;
            margin-right: auto;
        }
        
        </style>
        </head>";

    echo "<body style='background-image: url(../images/cityhotels.jpg); background-size: cover;'>";

    $ccode = $_SESSION['ccode'];

    $sql = "select count(*) as numhotels from hotel where hccode = $ccode";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $numhotels = $row["numhotels"];

    $sql = "select cname from city where ccode = $ccode";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    $cname = $row["cname"];
    echo "<div class = 'main'";
            
    echo "<p style = 'font-size: 30px;'>Hotels in ".$cname."</p>";    

            $sql = "select * from hotel where hccode = $ccode";
            $result = $conn->query($sql);

            echo "<table class = 'tbl' border = '1' cellpadding = '10'>";
            
            echo "<tr>";
            while ($row = $result->fetch_assoc())
            {
                echo "<th>".$row["hname"]."</th>"; 
            }
            echo "<tr>";

            $sql = "select * from hotel where hccode = $ccode";
            $result = $conn->query($sql);
            echo "<tr>";
            while ($row = $result->fetch_assoc())
            {
                echo "<td>".$row["address"]."</td>";     
            }
            echo "</tr>";   

            $sql = "select * from hotel where hccode = $ccode";
            $result = $conn->query($sql);
            echo "<tr>";
            while ($row = $result->fetch_assoc())
            {
                echo "<td>".$row["hdesc"]."</td>";     
            }
            echo "</tr>";   

            $sql = "select * from hotel where hccode = $ccode";
            $result = $conn->query($sql);
            echo "<tr>";
            while ($row = $result->fetch_assoc())
            {
                echo "<td>Contact: ".$row["contact"]."</td>";     
            }
            echo "</tr>";   

            $sql = "select * from hotel where hccode = $ccode";
            $result = $conn->query($sql);
            echo "<tr>";
            while ($row = $result->fetch_assoc())
            {
                $temp = $row["hid"];
                echo "<td><button><a href = 'hotelbook.php?var=$temp'>Book Room</a></button></td>";
            }
            echo "</tr>";   

            "</table>";
    
    echo "</div>";
    echo "</body>";
    $conn->close();

?>

