<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "../css_files/hotelbook_styles.css">
    <title>Book Hotel</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <script>
        $(function(){
        var dtToday = new Date();
    
        var month = dtToday.getMonth() + 1;
        var day = dtToday.getDate();
        var year = dtToday.getFullYear();
        if(month < 10)
            month = '0' + month.toString();
        if(day < 10)
            day = '0' + day.toString();
    
        var minDate= year + '-' + month + '-' + day;
    
        $('#date1').attr('min', minDate);
        $('#date2').attr('min', minDate);
        });
    </script>
    
    <script>   

        function validate()
        {
            var r = document.getElementsByName('roomtype');
            var d1 = document.getElementById('date1').value;
            var d2 = document.getElementById('date2').value;
            for (var i=0; i<r.length; i++)
            {
                if (r[i].checked == true)
                    break;
            }
            if (i == r.length)
            {
                alert("Please select a Room Type");
                return false;
            }
            else if (d1 > d2)
            {
                alert("Error: Check-in date should be before check-out date");
                return false;
            }
            return true;
        }
    
    </script>

    <style>
        
    </style>
</head>
<body>
<?php
        include_once "trip_db_connect.php";

        session_start();
        $hid = $_GET['var'];
        $_SESSION['hid'] = $hid;
        $userid = $_SESSION['userid'];

        $cost = array();
        for ($i=0; $i<4; $i++)
        {
            $j = $i+1;
            $sql = "select * from hotelroomdetails where hotelid = $hid and roomtypeid = $j;";
            $result = $conn->query($sql);
            while($row = $result->fetch_assoc())
            {
                $cost[$i] = $row["rcost"];
            }
        }
        $conn->close();
?>


<div class = "main">

<h2><u>Book Room</u></h1>

    <form action = "hotelbook_connect.php" method = "POST" onsubmit = "return validate()">

        <p>Please select room type:</p>
       
        <div class = "radio" style = "text-align: left; margin-left: 225px;">
        <table>
        <tr>    
            <td><input type="radio" id="room1" name="roomtype" value="1">
            <label for="room1">Deluxe AC</label></td>
            <td><?php echo "  ₹".$cost[0]." per night"; ?></td>
        </tr>

        <tr>
            <td><input type="radio" id="room2" name="roomtype" value="2">
            <label for="room2">Deluxe Non-AC</label></td>
            <td><?php echo "  ₹".$cost[1]." per night"; ?></td>
        </tr>

        <tr>    
            <td><input type="radio" id="room3" name="roomtype" value="3">
            <label for="room3">Non-Deluxe AC</label></td>
            <td><?php echo "  ₹".$cost[2]." per night"; ?></td>
        </tr>

        <tr>    
            <td><input type="radio" id="room4" name="roomtype" value="4">
            <label for="room4">Non-Deluxe Non-AC</label></td>
            <td><?php echo "  ₹".$cost[3]." per night"; ?></td>
        </tr>
        </table>
        </div>
        
        <p>Select number of rooms to book:</p>

        <input type="number" id="num" name="num" min="1" required><br><br>

        <label for="date1">Check-in Date:</label><br>
        <input type="date" id="date1" name="indate" value = "<?php echo date(Y-m-d) ?>" required><br><br>

        <label for="date2">Check-out Date:</label><br>
        <input type="date" id="date2" name="outdate" value = "<?php echo date(Y-m-d) ?>" required><br><br>

        <button class="btn">Book</button>
        
    </form>
</div>
</body>
</html>