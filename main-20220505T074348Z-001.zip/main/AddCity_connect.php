<?php


  include_once "trip_db_connect.php";  //Connect
  $city = htmlentities($_POST['city'], ENT_QUOTES);

  $sql = "select max(ccode) as cid from city";
  $result = $conn->query($sql);
  
  if ($result->num_rows == 0)
  {
      $ccode = 1;
  }
  else
  {
      $row = $result->fetch_assoc();
      $ccode = ++$row["cid"];
  }

  $sql = "call add_city($ccode, '$city')";
  //$sql = "insert into city (ccode, cname) values ($ccode, '$city')";
  if($conn->query($sql))
  {
      header('location: AddCity.html');
  }
  else
  {
      echo "error".$sql;
  }

  $conn->close();
 ?>

