<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Hotel Details</title>
    <link rel = "stylesheet" href = "../css_files/hotel_styles.css">;
</head>
<body style="background-image: url(../images/hotel_bg.jpg); background-size:cover;">

<?php
	$dbhost = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "trip_planner";
        
        //Connection:
        $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

        session_start();
?>

    <div class = "main">
    <form action = "hotel_connect.php" method = "POST">

    <h2>Please enter following details:</h2>
        
        <label for="name">Name of Hotel:</label><br>
        <input type="text" id="name" name="hname" style="width: 70%; height: 25px;" required><br><br>

        <label for="city">City:</label><br>
            <select name="city" id="city">
            <option>--select--</option>
            <?php
                $sql = "select * from city";
                $result = $conn->query($sql);
                while($row = $result->fetch_assoc())
                {   
                    $ccode = $row["ccode"];
                    $city = $row["cname"];
                    echo "<option value = '$ccode'>$city</option>";
                }
            ?>
            </select>

        <p>Room Types:</p>
    
        <table>
            
            <tr>
                <td>Deluxe AC:</td>
                <td>
                    <label for="room">No. of Rooms</label>
                    <input type="number" id="room" name="room1" min = "0" required>
                </td>

                <td>
                    <label for="cost">Cost</label>
                    <input type="number" id="cost" name="cost1" min="0" required>
                </td>
            </tr>

            <tr>
                <td>Deluxe Non-AC:</td>
                <td>
                    <label for="room">No. of Rooms</label>
                    <input type="number" id="room" name="room2" min = "0" required>
                </td>

                <td>
                    <label for="cost">Cost</label>
                    <input type="number" id="cost" name="cost2" min="0" required>
                </td>
            </tr>

            <tr>
                <td>Non-Deluxe AC:</td>
                <td>
                    <label for="room">No. of Rooms</label>
                    <input type="number" id="room" name="room3" min = "0" required>
                </td>

                <td>
                    <label for="cost">Cost</label>
                    <input type="number" id="cost" name="cost3" min="0" required>
                </td>
            </tr>

            <tr>
                <td>Non-Deluxe Non-AC:</td>
                <td>
                    <label for="room">No. of Rooms</label>
                    <input type="number" id="room" name="room4" min = "0" required>
                </td>

                <td>
                    <label for="cost">Cost</label>
                    <input type="number" id="cost" name="cost4" min="0" required>
                </td>
            </tr>

        </table>
        <br>
        

        

        <label for="hdesc">Describe Your Hotel</label><br>
        <textarea id="hdesc" name="hdesc" required></textarea><br><br>

        <label for="address">Hotel Address</label><br>
        <input type="text" id="address" name="address" style="width: 70%; height: 25px;" required><br><br>

        <label for="cont">Hotel Contact</label><br>
        <input type="text" id="cont" name="cont" required><br><br>

        <button class="btn">Add Details</button>

    </form>
    <?php
     $conn->close();
    ?>
</div>
</body>
</html>